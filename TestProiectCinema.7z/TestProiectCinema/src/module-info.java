module main {
    requires java.sql;
    exports com.company;
}